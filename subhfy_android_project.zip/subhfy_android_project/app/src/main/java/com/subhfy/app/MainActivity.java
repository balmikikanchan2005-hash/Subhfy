package com.subhfy.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int bg = Color.rgb(9,7,17), purple = Color.rgb(180,92,255);
    TextView nowPlaying;
    boolean playing = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(22, 30, 22, 18);
        page.setBackgroundColor(bg);

        TextView logo = text("subhfy", 34, Color.WHITE, true);
        page.addView(logo);
        TextView tagline = text("Your music. Your mood.", 14, 0xFFB9AFC8, false);
        page.addView(tagline);

        TextView heading = text("Discover", 23, Color.WHITE, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = 28;
        page.addView(heading, hp);

        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        for (String s : new String[]{"Bangla", "Hindi", "English"}) {
            TextView chip = text(s, 14, Color.WHITE, true);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(15, 10, 15, 10);
            chip.setBackground(round(purple, 24));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
            cp.rightMargin = 9; cp.topMargin = 12;
            chips.addView(chip, cp);
        }
        page.addView(chips);

        TextView songs = text("Popular picks", 21, Color.WHITE, true);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 28;
        page.addView(songs, sp);

        String[] titles = {"Midnight Vibes", "Moner Gaan", "Desi Beats", "Chill Waves"};
        String[] artists = {"subhfy mix • English", "Bangla collection", "Hindi collection", "Instrumental"};
        for (int i=0; i<titles.length; i++) {
            final String title = titles[i];
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(14, 12, 14, 12);
            row.setBackground(round(0xFF191426, 16));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.topMargin = 10;
            TextView cover = text("♫", 25, Color.WHITE, true);
            cover.setGravity(Gravity.CENTER);
            cover.setBackground(round(0xFF60309A, 12));
            row.addView(cover, new LinearLayout.LayoutParams(54,54));
            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            info.setPadding(13,0,0,0);
            info.addView(text(title, 16, Color.WHITE, true));
            info.addView(text(artists[i], 12, 0xFFB9AFC8, false));
            row.addView(info, new LinearLayout.LayoutParams(0,-2,1));
            TextView heart = text("♡", 25, purple, true);
            row.addView(heart);
            heart.setOnClickListener(v -> heart.setText(heart.getText().toString().equals("♡") ? "♥" : "♡"));
            row.setOnClickListener(v -> { nowPlaying.setText("Selected: " + title); });
            page.addView(row, rp);
        }

        View spacer = new View(this);
        page.addView(spacer, new LinearLayout.LayoutParams(1,0,1));
        LinearLayout player = new LinearLayout(this);
        player.setGravity(Gravity.CENTER_VERTICAL);
        player.setPadding(14,12,14,12);
        player.setBackground(round(0xFF28183B, 18));
        nowPlaying = text("Choose a song", 14, Color.WHITE, true);
        player.addView(nowPlaying, new LinearLayout.LayoutParams(0,-2,1));
        Button play = new Button(this);
        play.setText("▶");
        play.setTextColor(Color.WHITE);
        play.setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple));
        player.addView(play);
        play.setOnClickListener(v -> {
            playing = !playing;
            play.setText(playing ? "Ⅱ" : "▶");
            if (nowPlaying.getText().toString().equals("Choose a song"))
                nowPlaying.setText("Demo player • Add licensed audio to play");
        });
        page.addView(player);
        setContentView(page);
    }

    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    android.graphics.drawable.GradientDrawable round(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }
}
